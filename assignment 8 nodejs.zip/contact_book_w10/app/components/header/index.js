'use strict';

import React from 'react';

export default class Header extends React.Component {
    constructor() {
        super();
    }

    render() {
        return (
            <header>
                <h1>WEB615 Contact Book App</h1>
            </header>
        );
    }
}