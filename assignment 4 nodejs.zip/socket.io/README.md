# WEB615 Socket Client #

Simple client to test the Socket.IO implementation in our API

## Setup ##

The following are required as global dependencies:

* NodeJS

To install the local dependencies for the app run ``` npm i ```
