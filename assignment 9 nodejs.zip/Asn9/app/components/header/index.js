'use strict';

import React from 'react';

export default class Header extends React.Component {
    constructor() {
        super();
    }

    render() {
        return (
            <header>
                <h1>My Game of Thrones Contact Book App</h1>
            </header>
        );
    }
}