# WEB615 Contact Book #

Client side code for the Contact Book app

Each week will have its own branch. If you want the code from week 1 look in the week1 branch, week 2 look in week2 branch etc.

## Installation ##

To install the necessary dependencies run ``` npm i ```

## Running App ##

To build the static files run ``` npm run webpack ```

To launch the development server run ``` npm run server ```